-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 08:15 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spli`
--

-- --------------------------------------------------------

--
-- Table structure for table `bahasa`
--

CREATE TABLE `bahasa` (
  `id_user` varchar(50) NOT NULL,
  `id_bahasa` int(11) NOT NULL,
  `bahasa` varchar(50) NOT NULL,
  `tahap` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ibubapa`
--

CREATE TABLE `ibubapa` (
  `id_user` varchar(50) NOT NULL,
  `namabapa` varchar(50) NOT NULL,
  `noic_bapa` varchar(50) NOT NULL,
  `pekerjaanbapa` varchar(50) NOT NULL,
  `notel_bapa` varchar(50) NOT NULL,
  `namaibu` varchar(50) NOT NULL,
  `noic_ibu` varchar(50) NOT NULL,
  `pekerjaanibu` varchar(50) NOT NULL,
  `notel_ibu` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ibubapa`
--

INSERT INTO `ibubapa` (`id_user`, `namabapa`, `noic_bapa`, `pekerjaanbapa`, `notel_bapa`, `namaibu`, `noic_ibu`, `pekerjaanibu`, `notel_ibu`) VALUES
('alysha', 'ALMALIK KHALID BIN MASPOT', '750423016745', 'BEKERJA SENDIRI', '0113211312', 'SHALAZIAH BINTI MD ZIN', '750423016745', 'JURURAWAT', '01901928'),
('dayana', 'ABDUL AZIZ BIN ABDUL RAHMAN', '751231025051', 'SITE SUPERVISOR', '0102539003', 'HALIMAH BINTI ISMAIL', '751231025051', 'KERANI', '0126948597'),
('hafiza', '-', '-', '-', '-', 'MAZ', '-', 'MENJAGA SAYA', 'HAAA TEKA');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `image_data` mediumblob NOT NULL,
  `image_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kebolehan`
--

CREATE TABLE `kebolehan` (
  `id_user` varchar(50) NOT NULL,
  `id_kebolehan` int(11) NOT NULL,
  `kebolehan` varchar(50) NOT NULL,
  `tahap_kebolehan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `panduanojt`
--

CREATE TABLE `panduanojt` (
  `id_panduan` int(11) NOT NULL,
  `panduan` varchar(250) NOT NULL,
  `tarikh_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `panduanojt`
--

INSERT INTO `panduanojt` (`id_panduan`, `panduan`, `tarikh_masuk`) VALUES
(4, 'GP OJT_PERSEDIAAN SEBELUM DAN SEMASA OJT (4).pdf', '2023-01-26'),
(7, '1_ KVOJT 01- Borang Maklumat Pelajar-1.docx', '2023-01-30');

-- --------------------------------------------------------

--
-- Table structure for table `pelajar`
--

CREATE TABLE `pelajar` (
  `id_user` varchar(50) NOT NULL,
  `namapel` varchar(50) NOT NULL,
  `noic` varchar(14) NOT NULL,
  `tarikhlahir` date NOT NULL,
  `tempatlahir` varchar(50) NOT NULL,
  `adikberadik` int(50) NOT NULL,
  `jantina` varchar(50) NOT NULL,
  `bangsa` varchar(50) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `email` varchar(30) NOT NULL,
  `notel` varchar(14) NOT NULL,
  `gambar` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelajar`
--

INSERT INTO `pelajar` (`id_user`, `namapel`, `noic`, `tarikhlahir`, `tempatlahir`, `adikberadik`, `jantina`, `bangsa`, `agama`, `alamat`, `email`, `notel`, `gambar`) VALUES
('hafiza', 'SITI NUR HAFIZA BINTI MOHD NAZRI', '030429-14-0100', '2003-04-29', 'HOSPITAL TAWAKAL,KUALA LUMPUR', 5, 'Perempuan', 'Melayu', 'ISLAM', 'B7-10 PANGSAPURI ANGSANA,USJ 1 TAMAN SUBANG MEWAH,47610 SUBANG JAYA,SELANGOR', 's.nurhafiza29@gmail.com', '011-63872970', '─ 𝐖𝐎𝐔𝐑𝐅𝐋𝐎𝐏𝐀𝐃𝐎𝐒_♡ on Twitter.jpeg'),
('alysha', 'ALYSHA MAISARAH BINTI ALMALIK KHALID', '030827100550', '2003-08-27', 'HOSPITAL KAJANG', 4, 'Perempuan', 'Sila Pilih', 'ISLAM', 'NO 38, JALAN BM 3/7, SEKSYEN 3, BANDAR BUKIT MAHKOTA, 43000 KAJANG, SELANGOR', 'a1yshamaisar4h@gmail.com', '013-3727625', 'photo_2023-01-27_22-50-24.jpg'),
('dayana', 'NUR DAYANA BATRISYA BINTI ABDUL AZIZ', '031101030148', '2003-11-01', 'KOTA BHARU KELANTAN', 2, 'Perempuan', 'Melayu', 'ISLAM', 'A2-02-02 PANGSAPURI ANGSANA SUBANG MEWAH USJ 1 47610 SUBANG JAA SELANGOR', 'dayanabatrisya0717@gmail.com', '0134464497', '─ 𝐖𝐎𝐔𝐑𝐅𝐋𝐎𝐏𝐀𝐃𝐎𝐒_♡ on Twitter.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `pencapaian`
--

CREATE TABLE `pencapaian` (
  `id_user` varchar(12) NOT NULL,
  `id_kebolehan` int(11) NOT NULL,
  `pencapaian` varchar(100) NOT NULL,
  `tahap_pencapaian` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pencapaian`
--

INSERT INTO `pencapaian` (`id_user`, `id_kebolehan`, `pencapaian`, `tahap_pencapaian`) VALUES
('19/PD/01/15', 1, 'anugerah terbaik program', 'CGPA : 3.97'),
('alysha', 2, 'Anugerah Pengarah Semester 1 DVM', 'CGPA : 3.76');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id_user` varchar(50) NOT NULL,
  `id_pendidikan` int(11) NOT NULL,
  `nama_kolej` varchar(50) NOT NULL,
  `tahap` varchar(50) NOT NULL,
  `nama_kursus` varchar(100) NOT NULL,
  `diskripsi_pendidikan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengalamankerja`
--

CREATE TABLE `pengalamankerja` (
  `id_user` varchar(50) NOT NULL,
  `id_syarikat` int(11) NOT NULL,
  `nama_syarikat` varchar(50) NOT NULL,
  `jawatan_pass` varchar(50) NOT NULL,
  `tarikh_mula` date NOT NULL,
  `tarikh_tamat` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(12) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `username`, `password`, `usertype`) VALUES
(2, 'ALIF MUSTAQIM', '19/PD/01/01', '030516100959', 'user'),
(735, 'JASMINE', '19/PD/01/06', '030617101926', 'user'),
(147, 'IQBAL', '19/PD/01/11', '030308140251', 'user'),
(1, 'ABDULLAH AMIEN', '19/PD/01/15', '030924101627', 'user'),
(0, 'alep', 'alep', '1234', 'user'),
(4, 'ALYSHA MAISARAH', 'alysha', '030827100550', 'user'),
(17, 'azlina ahamad', 'azlina', '1234', 'admin'),
(166, 'DAYANA', 'dayana', '0987', 'user'),
(566, 'HAFIZA', 'hafiza', '1111', 'user'),
(752, 'HUDA', 'hanani', '0000', 'user'),
(585, 'irfan', 'irfan', '1234', 'user'),
(0, 'mus', 'mus', '0987', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `penyelia`
--

CREATE TABLE `penyelia` (
  `id_user` varchar(50) NOT NULL,
  `nama_penyelia` varchar(50) NOT NULL,
  `email_penyelia` varchar(30) NOT NULL,
  `notel_penyelia` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `id_user` varchar(50) NOT NULL,
  `id_resume` int(11) NOT NULL,
  `jawatan` varchar(50) NOT NULL,
  `infoprofil` varchar(250) NOT NULL,
  `gambar` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rujukan`
--

CREATE TABLE `rujukan` (
  `id_user` varchar(50) NOT NULL,
  `id_rujukan` int(11) NOT NULL,
  `nama_rujukan` varchar(50) NOT NULL,
  `jawatan_rujukan` varchar(50) NOT NULL,
  `no_tel_rujukan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `syarikat`
--

CREATE TABLE `syarikat` (
  `id_user` varchar(50) NOT NULL,
  `id_syarikat` int(11) NOT NULL,
  `namasyarikat` varchar(50) NOT NULL,
  `alamatsyarikat` varchar(50) NOT NULL,
  `emailsyarikat` varchar(50) NOT NULL,
  `notelsyarikat` varchar(50) NOT NULL,
  `namapic` varchar(50) NOT NULL,
  `notelpic` varchar(50) NOT NULL,
  `emailpic` varchar(50) NOT NULL,
  `suratjawapan` varchar(250) NOT NULL,
  `responsyarikat` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bahasa`
--
ALTER TABLE `bahasa`
  ADD PRIMARY KEY (`id_bahasa`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `ibubapa`
--
ALTER TABLE `ibubapa`
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kebolehan`
--
ALTER TABLE `kebolehan`
  ADD PRIMARY KEY (`id_kebolehan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `panduanojt`
--
ALTER TABLE `panduanojt`
  ADD PRIMARY KEY (`id_panduan`);

--
-- Indexes for table `pelajar`
--
ALTER TABLE `pelajar`
  ADD PRIMARY KEY (`noic`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Indexes for table `pencapaian`
--
ALTER TABLE `pencapaian`
  ADD PRIMARY KEY (`id_kebolehan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id_pendidikan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `pengalamankerja`
--
ALTER TABLE `pengalamankerja`
  ADD PRIMARY KEY (`id_syarikat`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `penyelia`
--
ALTER TABLE `penyelia`
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`id_resume`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `rujukan`
--
ALTER TABLE `rujukan`
  ADD PRIMARY KEY (`id_rujukan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `syarikat`
--
ALTER TABLE `syarikat`
  ADD PRIMARY KEY (`id_syarikat`),
  ADD KEY `id_user` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bahasa`
--
ALTER TABLE `bahasa`
  MODIFY `id_bahasa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kebolehan`
--
ALTER TABLE `kebolehan`
  MODIFY `id_kebolehan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `panduanojt`
--
ALTER TABLE `panduanojt`
  MODIFY `id_panduan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pencapaian`
--
ALTER TABLE `pencapaian`
  MODIFY `id_kebolehan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengalamankerja`
--
ALTER TABLE `pengalamankerja`
  MODIFY `id_syarikat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `id_resume` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rujukan`
--
ALTER TABLE `rujukan`
  MODIFY `id_rujukan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `syarikat`
--
ALTER TABLE `syarikat`
  MODIFY `id_syarikat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bahasa`
--
ALTER TABLE `bahasa`
  ADD CONSTRAINT `bahasa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ibubapa`
--
ALTER TABLE `ibubapa`
  ADD CONSTRAINT `ibubapa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `kebolehan`
--
ALTER TABLE `kebolehan`
  ADD CONSTRAINT `kebolehan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pelajar`
--
ALTER TABLE `pelajar`
  ADD CONSTRAINT `pelajar_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pengguna` (`username`) ON UPDATE CASCADE;

--
-- Constraints for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD CONSTRAINT `pendidikan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pengalamankerja`
--
ALTER TABLE `pengalamankerja`
  ADD CONSTRAINT `pengalamankerja_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `penyelia`
--
ALTER TABLE `penyelia`
  ADD CONSTRAINT `penyelia_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resume`
--
ALTER TABLE `resume`
  ADD CONSTRAINT `resume_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rujukan`
--
ALTER TABLE `rujukan`
  ADD CONSTRAINT `rujukan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `syarikat`
--
ALTER TABLE `syarikat`
  ADD CONSTRAINT `syarikat_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pelajar` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
