<?php
include'../../loginserver.php';
include '../../config.php';
session_start();

$_SESSION['user']=$username;
$name=$_SESSION["username"];
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../form.css">

    <style>
body {
  padding-bottom: 20px;
      background: linear-gradient(to right, CadetBlue, DarkGrey);
}

.navbar {
  margin-bottom: 20px;
      background: linear-gradient(to right, gray, beige);

}

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
 
    </style> 

    <script>
    function submitForm() {
      // Validate form fields
      // Submit form to server
      alert("Maklumat Anda Berjaya Dihantar!");
      return false;
    }
  </script>

  </head>
  <body>
    
<main>

  <div class="container-xl mb-4">
    <center><p>
      <h2>SISTEM PERSEDIAAN LATIHAN INDUSTRI</h2><p>
    </center>
    

   <nav class="navbar navbar-expand-sm bg-light rounded" aria-label="Twelfth navbar example">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Main For Creating Navigation Bar-->
 <div class="collapse navbar-collapse justify-content-md-center" id="navbar">
          <ul class="navbar-nav">

            <!-- Nav Bar -->
            <li class="nav-item">
              <a class="nav-link"href="../homepagestudent.php">Panduan On-Job Training(OJT)</a>
            </li>

            <li class="nav-item">
              <a class="nav-link " href="../paparborangmaklumat2.php">Maklumat Pelajar</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="../papar_resume.php">Resume Pelajar</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../paparmaklumatsyarikat.php">Maklumat Syarikat</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../../login2.php" onclick="return confirm('Anda Pasti Mahu Log Keluar?')">Log Keluar</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
<center>
  <?php

$query ="SELECT * FROM pelajar LEFT JOIN ibubapa ON pelajar.id_user=ibubapa.id_user WHERE pelajar.id_user='".$_SESSION['username']."'";
$query_run=mysqli_query($conn,$query);

if (mysqli_num_rows($query_run)>0) {
    ?>
    <br>
    <h5>Borang Telah Diisi</h5>
    <button class="btn"><a href="../homepagestudent.php">Kembali</a></button>
    <?php
}else{
  ?>

  <div class="card"style="width: 45rem;">
    <div class="card-header">
      <h4>Borang Maklumat Pelajar:</h4>
    </div>
    <div class="card-body">
    <h6 class="text-muted">Sila Isi Menggunakan Huruf Besar</h6>
    <form onsubmit="return submitForm()" action="prosborangmaklumat.php" class="form-control" id="regForm" method="POST"enctype="multipart/form-data" novalidate>
  
  <!-- One "tab" for each step in the form: -->
<div class="tab">
    <br>
    <div class="form-group row">
        <label for="nama" class="col-sm-3 col-form-label" >Nama :</label>
        <div class="col-sm-9">
          <input type="text" name="namapel" class="form-control" required><p>
        </div>
    </div>
    <div class="form-group row">
        <label for="no_ic" class="col-sm-3 col-form-label" data-toggle="tooltips" placement="top" title="Termasuk (-)">No Kad Pengenalan :</label>
        <div class="col-sm-9" >
          <p><input type="text" name="noic" class="form-control" required></p>
        </div>
    </div>
    <div class="form-group row">
        <label for="tarikh_lahir" class="col-sm-3 col-form-label" >Tarikh Lahir :</label>
        <div class="col-sm-3">
          <p><input type="date" name="tarikhlahir" class="form-control" required></p>
        </div>
    </div>
    <div class="form-group row">
        <label for="tempat_lahir" class="col-sm-3 col-form-label" >Tempat Lahir :</label>
        <div class="col-sm-9">
          <p><input type="text" name="tempatlahir" class="form-control" required></p>
        </div>
    </div>
    <div class="form-group row">
        <label for="bil_adik" class="col-sm-3 col-form-label" >Bilangan Adik Beradik :</label>
        <div class="col-sm-3">
          <p><input type="number" name="adikberadik" class="form-control" required></p>
        </div>
    </div>
    <div class="form-group row">
        <label for="jantina" class="col-sm-3 col-form-label" >Jantina :</label>
        <div class="col-sm-3">
          <div class="form-check">
              <input class="form-check-input" type="radio" name="jantina" id="lelaki" value="Perempuan" checked>
              <label class="form-check-label" for="lelaki">
                Perempuan
              </label>
            <!-- For Lelaki -->
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="jantina" id="Perempuan" value="lelaki">
            <label class="form-check-label" for="Perempuan">
              Lelaki
            </label>
          </div>
        </div>
    </div><br>
    <div class="form-group row">
        <label for="bil_adik" class="col-sm-3 col-form-label" >Bangsa :</label>
        <div class="col-sm-3">
          <select id="select1" class="form-select" name="bangsa" required>
            <option selected>Sila Pilih</option>
            <option>Melayu</option>
            <option>Cina</option>
            <option>India</option>
            <option>Lain-Lain</option>
          </select>
        </div>
    </div><br>

    <div class="form-group row">
        <label for="nama" class="col-sm-3 col-form-label" >Agama :</label>
        <div class="col-sm-3">
          <input type="text" name="agama" class="form-control" required><p>
        </div>
    </div>
    <div class="form-group row">
        <label for="alamat" class="col-sm-3 col-form-label">Alamat :</label>
          <div class="col-sm-9" >
          <textarea class="form-control" name="alamat" placeholder="Alamat" rows="3" required></textarea>
      </div>
    </div><br>
  <div class="form-group row">
        <label for="email" class="col-sm-3 col-form-label" >Email :</label>
        <div class="col-sm-9">
          <input type="email" name="email" class="form-control" required><p>
        </div>
  </div>
    <div class="form-group row">
        <label for="notel" class="col-sm-3 col-form-label" >Nombor Telefon :</label>
        <div class="col-sm-9">
          <input type="text" name="notel" class="form-control" required><p>
        </div>
    </div>

    <div class="form-group row">
      <label for="gambar" class="col-sm-3 col-form-label"> Gambar</label>
      <div class="col-sm-7">
        <h6 class="text-muted">Gambar Mestilah Berukuran 45x35 mm (Ukuran Passport)</h6>
        <input type="file" name="gambar" class="form-control"><p>
      </div>
      <br>
    </div>
</div>

<!-- ------------------------FORM UTK AYAH------------------------ -->
  <div class="tab">
    Maklumat Bapa:
    <h6 class="text-muted">Jika Tidak Berkenaan, Sila Letakkan ( - ) atau 'Tiada'</h6>
    <div class="form-group row">
        <label for="namabapa" class="col-sm-3 col-form-label" >Nama Bapa /Penjaga :</label>
        <div class="col-sm-9">
          <input type="text" name="namabapa" class="form-control" required><p>
        </div>
    </div>
    <div class="form-group row">
        <label for="noic_bapa" class="col-sm-3 col-form-label" >Nombor Kad Pengenalan :</label>
        <div class="col-sm-9">
          <input type="text" name="noic_bapa" class="form-control" required><p>
        </div>
    </div>
    <div class="form-group row">
        <label for="pekerjaanbapa" class="col-sm-3 col-form-label" >Pekerjaan :</label>
        <div class="col-sm-9">
          <input type="text" name="pekerjaanbapa" class="form-control" required><p>
        </div>
    </div>
    <div class="form-group row">
        <label for="nocontact" class="col-sm-3 col-form-label" >Nombor Telefon :</label>
        <div class="col-sm-9">
          <input type="text" name="notelbapa" class="form-control" required><p>
        </div>
    </div>
  </div>
  <!---tab IBU----->
  <div class="tab">Maklumat Ibu:
    <h6 class="text-muted">Jika tiada Ibu sila isi tiada</h6>
    <div class="form-group row">
          <label for="namaibu" class="col-sm-3 col-form-label" >Nama Ibu/Penjaga :</label>
          <div class="col-sm-9">
            <input type="text" name="namaibu" class="form-control" required><p>
          </div>
      </div>
    <div class="form-group row">
          <label for="no_ic" class="col-sm-3 col-form-label" >Nombor Kad Pengenalan :</label>
          <div class="col-sm-9">
            <input type="text" name="noic_ibu" class="form-control" required><p>
          </div>
      </div>
      <div class="form-group row">
          <label for="pekerjaanibu" class="col-sm-3 col-form-label" >Pekerjaan :</label>
          <div class="col-sm-9">
            <input type="text" name="pekerjaanibu" class="form-control" required><p>
          </div>
      </div>
      <div class="form-group row">
          <label for="nocontact" class="col-sm-3 col-form-label" >No Telefon :</label>
          <div class="col-sm-9">
            <input type="text" name="notel_ibu" class="form-control" required><p>
          </div>
      </div>
</div>
  <div style="overflow:auto;">
    <div style="float:right;">
      <button type="button" id="prevBtn" onclick="nextPrev(-1)" class="btn btn-warning">Kembali</button>
      <button type="button" id="nextBtn" onclick="nextPrev(1)"class="btn btn-success">Seterusnya</button>
      <button type="reset" id="resetBtn" onclick="reset(1)" class="btn btn-primary">Kosongkan</button>
    </div>
  </div>
  <!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span>
    <span class="step"></span>
  </div>
</form>
</div>
</div>
  <?php
}
  ?>
</center>
</main>


    <script src="..\assets\dist\js\bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="../form.js"></script>
    <script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
      
  </body>
</html>
