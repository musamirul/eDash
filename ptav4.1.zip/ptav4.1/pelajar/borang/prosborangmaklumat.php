<?php

include '../../config.php';
// include'../../loginserver.php';
$statusMsg='';

$targetDir="../../uploads/";
$fileName = basename($_FILES["gambar"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
 $allowTypes = array('jpg','png','jpeg','gif','pdf');

session_start();

$_SESSION['user']=$username;
$name=$_SESSION["username"];
/* ( [''] is the name we declared in the FORM )
 meanwhile
 ( $namapel is name in DB ) */

 // var kita set untuk pegang data form        ||    FORM       //
 $id_user=$_SESSION['username'];
$namapel=$_POST['namapel'];
$noic=$_POST['noic'];
$tarikhlahir=$_POST['tarikhlahir'];
$tempatlahir=$_POST['tempatlahir'];
$adikberadik=$_POST['adikberadik'];
$jantina=$_POST['jantina'];
$bangsa=$_POST['bangsa'];
$agama=$_POST['agama'];
$alamat=$_POST['alamat'];
$emel=$_POST['email'];
$notel=$_POST['notel'];



// maklumat ibu bapa
$namabapa=$_POST['namabapa'];
$noic_bapa=$_POST['noic_bapa'];
$pekerjaanbapa=$_POST['pekerjaanbapa'];
$notel_bapa=$_POST['notelbapa'];
$namaibu=$_POST['namaibu'];
$noic_ibu=$_POST['noic_ibu'];
$pekerjaanibu=$_POST['pekerjaanibu'];
$notel_ibu=$_POST['notel_ibu'];


$query= "INSERT INTO pelajar (
        id_user,
        namapel, /*dalam DB */
        noic,
        tarikhlahir,
        tempatlahir,
        adikberadik,
        jantina,
        bangsa,
        agama,
        alamat,
        email,
        notel
        ) VALUES(
        '$id_user',
        '$namapel', /* yang kita set kat atas */
        '$noic', /* follow line 9 sampai 27 */
        '$tarikhlahir',
        '$tempatlahir',
        '$adikberadik',
        '$jantina',
        '$bangsa',
        '$agama',
        '$alamat',
        '$emel',
        '$notel')";
$query2="INSERT INTO ibubapa(
        id_user,
        namabapa,
        noic_bapa,
        pekerjaanbapa,
        notel_bapa,
        namaibu,
        noic_ibu,
        pekerjaanibu,
        notel_ibu) VALUES(
        '$id_user',
        '$namabapa',
        '$noic_bapa',
        '$pekerjaanbapa',
        '$notel_bapa',
        '$namaibu',
        '$noic_bapa',
        '$pekerjaanibu',
        '$notel_ibu')";

$query_run=mysqli_query($conn,$query);
$query_run2=mysqli_query($conn,$query2);

 if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
            $insert = $conn->query("UPDATE pelajar SET gambar = '".$fileName."' WHERE id_user = '$id_user'");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }else{
                $statusMsg = "File upload failed, please try again.";
            } 
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";
        }
    }else{
        $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
    }


if ($query_run) {
    echo "Data Berjaya Disimpan";
    echo $statusMsg;
    header('location:../paparborangmaklumat.php');
}

else {
    echo "Data Tidak Berjaya Disimpan";
    echo $statusMsg;
    echo "<a href='../homepagestudent.php'>KEMBALI</a>";
}

?>