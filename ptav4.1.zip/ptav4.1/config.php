<?php

$servername="localhost";
$username="root";
$password="";
$db="spli";

$conn= mysqli_connect($servername,$username,$password,$db);

?>