<?php
session_start();

require '../config.php';
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<style>
        .card{
        margin-left: 40%;
        margin-right: -18%;
    }
</style>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Cipta Akaun Pelajar</title>
</head>
<body style="background-color: #c4b7a6;">
   
    <div class="container mt-5">

    <?php include('message.php'); ?>

        <div class="row"> 
            <div class="col-md-8">
                <div class="card" style="width: 39rem;">
                    <div class="card-header">
                        <h4>Tambah Akaun Pelajar
                            <a href="accPelajar.php" class="btn btn-danger float-end">Kembali</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="pros_addPelajar.php" method="POST">
<?php 
$id=mt_rand(111,999);
?>
                            <div class="mb-3">
                                <label>Bil</label>
                                <input readonly type="number" name="id" class="form-control mb-6" value="<?php echo $id; ?>">
                            </div>
                            <div class="mb-3">
                                <label>Nama Pelajar</label>
                                <input type="text" name="nama" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label>ID Matriks Pelajar</label>
                                <input type="text" name="username" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label>Kata Laluan</label>
                                <input type="text" name="password" placeholder="Tanpa (-)" class="form-control">
                            </div>
                            <div class="mb-3">
                            <label for="usertype" class="col-sm-3 col-form-label" >Jenis Pengguna :</label>
                                <div class="col-sm-3">
                            <select id="select1" class="form-select" name="usertype" required>
                                <option selected>Sila Pilih</option>
                                <option>user</option>
                                <option>admin</option>
                            </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="save_student" class="btn btn-primary">Simpan Maklumat</button>
                            </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>