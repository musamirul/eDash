<?php

include('../config.php');

$id = $_GET['id'];
$dbh=mysqli_connect("localhost", "root", "", "spli");

$sql = "DELETE FROM pengguna WHERE id = '$id'";
$query = mysqli_query($dbh,$sql);
if ($query) {
  header("location:accPelajar.php");
}
else{
  echo "Gagal";
}
?>